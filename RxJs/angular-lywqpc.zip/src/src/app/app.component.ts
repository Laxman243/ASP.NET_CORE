import { Component } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
// RxJS v6+

/*
  Create an observable that emits 'Hello' and 'World' on  
  subscription.
*/
 hello = Observable.create(function(observer) {
  observer.next('Hello');
  observer.next('World');
});

//output: 'Hello'...'World'
subscribe = this.hello.subscribe(val => console.log(val));


}
